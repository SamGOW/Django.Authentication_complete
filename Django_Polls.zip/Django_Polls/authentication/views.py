from django.shortcuts import render
from authentication.forms import UserForm
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponseRedirect, HttpResponse
from django.urls import reverse
from .models import User
from django.contrib.auth.decorators import login_required


def index(request):
    return render(request,'index.html')

@login_required
def special(request):
    return HttpResponse("You are logged in !")

@login_required
def user_logout(request):
    logout(request)
    return HttpResponseRedirect(reverse('index'))

def register(request):
    registered = False
    if request.method == 'POST':
        user_form = UserForm(request.POST)
        print('debug1')
        if user_form.is_valid():
            username = user_form.cleaned_data.get('username')
            password = user_form.cleaned_data.get('password')
            dob = user_form.cleaned_data.get('date_of_birth')
            email = user_form.cleaned_data.get('email')
            print('debug1.1')
            profile_pic = user_form.cleaned_data.get('profile_pic')
            print('debug2')
            user = User.objects.create_user(username=username, date_of_birth=dob,email=email,profile_pic=profile_pic, password=password)
            print('debug3')
            if 'profile_pic' in request.FILES:
                print('found it')
                user.profile_pic = request.FILES['profile_pic']
            user.save()
            registered = True
        else:
            print(user_form.errors)
    else:
        user_form = UserForm()
    return render(request, 'signup.html',
                  {'user_form': user_form,
                   'registered': registered})

def user_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username=username, password=password)
        if user:
            if user.is_active:
                login(request,user)
                return HttpResponseRedirect(reverse('index'))
            else:
                return HttpResponse("Your account was inactive.")
        else:
            print("Someone tried to login and failed.")
            print("They used username: {} and password: {}".format(username,password))
            return HttpResponse("Invalid login details given")
    else:
        return render(request, 'login.html')