from django import forms
from authentication.models import User
class UserForm(forms.ModelForm):
    username = forms.CharField(max_length=200)
    date_of_birth = forms.DateField()
    email = forms.EmailField()
    password = forms.CharField(widget=forms.PasswordInput())

    class Meta():
        model = User
        fields = ('username', 'date_of_birth', 'email', 'profile_pic', 'password')

    def __init__(self, *args, **kwargs):
        super(UserForm, self).__init__(*args, **kwargs)
        self.fields['profile_pic'].required = False

